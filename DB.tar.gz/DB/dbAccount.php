<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$hostname = "localhost";
$username = "root";
$project  = "db490";
$password = "1234";

($db = mysqli_connect($hostname, $username, $password, $project)) OR
die("Failed connect MYSQL: " . mysqli_connect_error());
mysqli_select_db($db, $project);
echo "MYSQL success";


?>
