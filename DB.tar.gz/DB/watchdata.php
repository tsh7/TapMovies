<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

//This processes creating account using the data received from webserver
    include 'dbAccount.php';//Database access
    /*
      insert codes to store watched/tobe data to database here
      task
      Username
      M_id
    */
    $task = $data["task"];
    $username = $data["username"];
    $movieid = $data["M_id"];
    if ($task = "watched") {
        $qry_check = "SELECT * FROM watched WHERE Username = '$username' and MovieID='$movieid'";//define query
        $result_check = mysqli_query($db, $qry_check);//process query
        $num_rows_check = mysqli_num_rows($result_check);//store the query result

        switch ($num_rows_check) {
            case '0'://if the result is 0, create account in Database.
                $sql = "INSERT INTO watched (Username, MovieID) VALUES ('$username', '$movieid')";
                if ($db->query($sql) === true) {
                    $R_Data = array("Function"=>"watchdata","W_result"=>"Success");
                }
                break;
            case '1': //If the result is 1, the user account exists. Return error message
                $R_Data = array("Function"=>"watchdata","W_result"=>"Exists");
                break;
            default://if others, something went worng
                $R_Data = array("Function"=>"watchdata","W_result"=>"Error");
        }
    } elseif ($task = "tobewatched") {
        $qry_check = "SELECT * FROM tobewatched WHERE Username = '$username' and MovieID='$movieid'";//define query
      $result_check = mysqli_query($db, $qry_check);//process query
      $num_rows_check = mysqli_num_rows($result_check);//store the query result

      switch ($num_rows_check) {
          case '0'://if the result is 0, create account in Database.
              $sql = "INSERT INTO tobewatched (Username, MovieID) VALUES ('$username', '$movieid')";
              if ($db->query($sql) === true) {
                  $R_Data = array("Function"=>"watchdata","W_result"=>"Success");
              }
              break;
          case '1': //If the result is 1, the user account exists. Return error message
              $R_Data = array("Function"=>"watchdata","W_result"=>"Exists");
              break;
          default://if others, something went worng
              $R_Data = array("Function"=>"watchdata","W_result"=>"Error");
      }
    } elseif ($task = "watchedList") {
        $qry_check = "SELECT * FROM watched WHERE Username = '$username' and MovieID='$movieid'";//define query
      $result_check = mysqli_query($db, $qry_check);//process query
      $num_rows_check = mysqli_num_rows($result_check);//store the query result

      switch ($num_rows_check) {
          case '0'://if the result is 0, create account in Database.
              $R_Data = array("Function"=>"watchdata","W_result"=>"No Data");
              break;
          case '1': //If the result is 1, the user account exists. Return error message
              $total = 0;
              while($row = mysql_fetch_array($result_check)){   //Creates a loop to loop through results
                    $total++;
                    $R_Data = array("list"=>$row['MovieID']);  //$row['index'] the index here is a field name
              }
              $R_Data = array("total"=>$total);
              break;
          default://if others, something went worng
              $R_Data = array("Function"=>"watchdata","W_result"=>"Error");
      }
    } else {
        $R_Data = array("Function"=>"watchdata","W_result"=>"Error");
    }

    include 'DB_T_WWW.php';//return the result to the Web server
