<?php
$msg= $_POST['selectState'];
echo $msg;
?>