<html>
	<head>
	</head>
		<body>
<!-- <button id="create_account_button" onclick="document.getElementById('id01').style.display='block'" style="width:auto;"><b>Create Account</b></button>
<button type="button" name="Singup" id="Signup" class="btn btn-success" data-toggle="modal" data-target="#Signup_Modal">Create Account</button> -->
  <link rel="stylesheet" type="text/css" href="main.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

   <div align="center">
   <button type="button" name="Signupbtn" id="Signupbtn" class="btn btn-success" data-toggle="modal" data-target="#loginModal">Create Account</button>
   </div>
<div id="loginModal" class="modal fade" role="dialog">
<div class="modal-dialog">
   <!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h2 class="modal-title">Create Account</h2><hr><br>
				</div>
				<div class="modal-body">
				
					<label><b>Select one of the following</b></label><br><br>
					<input type="radio" placeholder="Select one" name="U_level" id="U_level" value="Student" required>College Student
					<input type="radio" placeholder="Select one" name="U_level" id="U_level" value="Others" required>Others<br /><br />
					
					<div id="state_div">
					<label>State</label>
					<input list="StateBrowsers2" name="StateBrowsers2" id="selectState2" class="form-control">
					<datalist id="StateBrowsers2">
						<option>         </option>
						<option value="NJ" >New Jersey</option>
						<option value="NY">New York</option>
					</datalist>
					<br /><br />
					</div>
					
					<div id="School_div">
					<label>School</label>
						<input list="SchoolBrowsers2" name="SchoolBrowsers2" id="school2" class="form-control" />
						<datalist id="SchoolBrowsers2">
							<div id="displaySchools2"></div>
						</datalist>
					<br><br>
					</div>
					
					<label>Email</label>
					<input type="Email" name="Email" id="Email" class="form-control" />
					<br><br>
					
					<label>Password</label>
					<input type="Password" name="Password" id="Password" class="form-control" />
					<br /><br />
					
					<label>Confirm Password</label>
					<input type="Password" name="Password_repeat" id="Password_repeat" class="form-control" />
					<br />
          <br>
					
					<button type="button" name="Signup_button" id="Signup_button" class="btn btn-warning">Create Account</button>
          <button type="button" name="Cancel_button" onclick="window.location='index.php'" class="cancelbtn">Cancel</button>
          <br><br>
				</div>
			</div>
		</div>
 </div>
</body>
</html>