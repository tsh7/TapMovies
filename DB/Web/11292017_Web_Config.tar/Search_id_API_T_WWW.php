<?php

require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPConnection;

$connection = new AMQPConnection('192.168.1.101', 5672, 'admin', 'guest');
$channel = $connection->channel();

$channel->queue_declare('API_T_WWW', false, false, false, false);

//echo ' * Waiting for messages. To exit press CTRL+C', "\n";

$callback = function($msg){

//echo " * Message received", "\n";

$R_Data = json_decode($msg->body, true);
$M_id=$R_Data['id'];
$img_dir="https://image.tmdb.org/t/p/w500";
$img=$R_Data['backdrop_path'];
echo "<table style='float: left; width=30%'>";
	echo "<tr>";
		echo "<td>";
		echo "<img src='".$img_dir.$img."' style='width:300;height:300;'>";
		echo "</td>";
	echo "</tr>";
echo "</table>";
echo "<table style='float: left; width=50%'>";
	echo "<tr>";
		echo "<td>";
			echo "Genres: ";
		echo "</td>";
		echo "<td>";
			echo $R_Data['genres'][0]['name'];
		echo "</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>";
			echo "Title: ";
		echo "</td>";
		echo "<td>";
			echo $R_Data['title'];
		echo "</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>";
			echo "Homepage: ";
		echo "</td>";
		echo "<td>";
			echo $R_Data['homepage'];
		echo "</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>";
			echo "Budget: ";
		echo "</td>";
		echo "<td>";
			echo "$	".$R_Data['budget'];
		echo "</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>";
			echo "Popularity: ";
		echo "</td>";
		echo "<td>";
			echo $R_Data['popularity'];
		echo "</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>";
			echo "ID: ";
		echo "</td>";
		echo "<td>";
			echo $R_Data['id'];
		echo "</td>";
	echo "</tr>";
	echo "<tr>";
	echo "<td>";
			echo "<a href='myaccount.php?W_M_id=".$M_id."'><button>Watched</button></a>";
			//echo "<a href='myaccount.php?watched=<input type='button' id='watched' action='myhome.php?Watched=".$R_Data['id']."' value='Watched'>";
		echo "</td>";
		echo "<td>";
			echo "<input type='button' id='T_watched' action='T_watched()' value='To be watched'>";
		echo "</td>";
	echo "</tr>";
echo "</table>";
};

$channel->basic_consume('API_T_WWW', '', false, true, false, false, $callback);
//while(count($channel->callbacks)){
$channel->wait();
//}
$channel->close();
$connection->close();
?>