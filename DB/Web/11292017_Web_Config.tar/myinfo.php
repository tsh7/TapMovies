<html>
	<head>
		<title>TapMovies</title>
		<link rel="stylesheet" type="text/css" href="main.css">
	</head>
	<?php
	session_start();
	?>
	

	<body>

		<div id="wrapper">
			
			<div id="header">
				<img src="colab.png" alt="SCL Logo" class="float_left">
				<h1 class="float_left">TapMovies</h1>

<?php

if(!isset($_SESSION['Email'])){
	if(!isset($_POST['Login'])){
		readfile('Login.html');
		readfile('Create_Account.html');
	}elseif(($_POST['Email']=='') or ($_POST['Password']=='')){
		header("Location: index.php");
	}else{
		$Email=$_POST['Email'];
		$Pword_text=$_POST['Password'];
		include 'Login_WWW_T_DB.php';
	}
}elseif(isset($_SESSION['Email'])){
	if(!isset($_POST['Logout'])){
		include "Logout.html";
		
	}elseif(isset($_POST['Logout'])){
		session_unset();
		session_destroy();
		header("Location: index.php");
	}
}
?>
			</div>
			<div id="aa">
				<div id="introtxt">
					<h1>Welcome to TapMovies</h1>
					<h4 id="introtext"><i>We provide unlimited movie information</i><h4>
				</div>

				
					<div>
					<?php
						include "Watched_M_List.php";
					?>
					</div>

					
		
			</div>

		</div>
	</body>
</html>