<?php
	$conn = mysqli_connect("sql.njit.edu","mk599","2MdBJthf","mk599");
?>