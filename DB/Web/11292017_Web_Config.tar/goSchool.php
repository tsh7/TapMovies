<?php
$School_value = $_POST["SchoolBrowsers"];
switch(){
	case 'New Jersey Institute of Technology':
		header("Location: NJIT_courses.php");
	case 'Princeton University':
		header("Location: Princeton_courses.php");
	default
		header("Location: index.php");
}
?>