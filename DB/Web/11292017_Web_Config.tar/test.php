<html>
<body>
<?php
session_start();
include 'db.php';
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
		$Email = "aca";
		$Password = "aca";
		$query = "select U_id, Email from User where Email='$Email' and Password='$Password'";
        $strSQL = mysqli_query($conn,$query);
        $Results = mysqli_num_rows($strSQL);
		$row = mysqli_fetch_assoc($strSQL);
		echo "<h>haha</h>";
		
		//echo $row["Email"];
		//echo $row["U_id"];
		
?>
</body>
</html>