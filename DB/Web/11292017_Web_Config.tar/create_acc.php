<!DOCTYPE html>
<html>
	<head>
		<title>Create Account</title>
		<link rel="stylesheet" type="text/css" href="main.css">
	</head>
	<body>
			<div id="wrapper">
			
			<div id="header">
				<a href="index.php"><img src="colab.png" alt="SCL Logo" class="float_left" ></a>
				<h1 class="float_left">TapMovies</h1>
				</div>
				
		<form id="modal_content" class="modal-content" method="post" action="Register_WWW_T_DB.php">
					<div class="container">
					  
					  <h1>Create Account</h1>
					  
					  <label><b>First Name</b></label><br>
					  <input type="text" placeholder="Enter First Name" id="Fname" name="Fname"><br><br>
					  
					  <label><b>Last Name</b></label><br>
					  <input type="text" placeholder="Enter Last Name" id="Lname" name="Lname"><br><br>
					  
					  <label><b>Email </b></label><br>
					  <input type="text" placeholder="Enter Email" name="Email" id="Email" required><br><br>

					  <label><b>Phone </b></label><br>
					  <input type="text" placeholder="Enter Phone number" name="Phone" id="Phone" required><br><br>					  
					  
					  <label><b>Password</b></label><br>
					  <input type="password" placeholder="Enter Password" name="Password" id="Password" required><br><br>

					  <label><b>Repeat Password</b></label><br>
					  <input type="password" placeholder="Repeat Password" name="Password_repeat" id="Password_repeat"required><br>
					  <input type="checkbox" checked="checked"> Remember me<br>
					  <p>By creating an account you agree to our <a href="https://www.google.com" style="color:black;font-size:14px"><b>Terms & Privacy</b></a>.</p>

					  <div id="modle_buttons" class="clearfix">
						<a href="index.php"><button type="button" onclick="window.location='index.html'" class="cancelbtn">Cancel</button></a>
						<button type="submit" id="Signup_button" class="signupbtn">Sign Up</button>
					  </div>
					</div>
		</form>
		</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
 <script>
$(document).ready(function(){
		$('#Signup_button').click(function(){
				var Fname = $('#Fname').val();
				var Lname = $('#Lname').val();
				var Email = $('#Email').val();
				var Phone = $('#Phone').val();
				var Password = $('#Password').val();
				var Password_repeat = $('#Password_repeat').val();
				
				if(Fname != '' && Lname != '' && Email != '' && Phone != '' && Password != '' && Password == Password_repeat)
				{
					$.ajax({
						url:"Register_WWW_T_DB.php",
						method:"POST",
						data:{Fname:Fname, Lname:Lname, Email:Email, Phone:Phone, Password:Password},
						success:function(data)
						{
							if($.trim(data) == "Good")
							{
								alert("Thank you for creating an account");
							}
							else if(data == "Error")
							{
								alert("Signup failed. Please try again");
							}
							else{
								alert("Something wrong");
							}
						}
					});
				}
				else
				{
						alert("Please check your input again. Registration failed");
				}
		});
});
			
</script>
	</body>
</html>