<?php
	include 'db.php';

		$Fname = $_POST['Fname'];
		$State = $_POST['Lname'];
		$S_name = $_POST['Email'];
		$Email = $_POST['Phone'];
		$password = $_POST['password'];

		$Signup_query = "INSERT INTO User (Fname, Lname, Email, Phone, Pword) VALUES ('$U_level', '$State', '$S_name', '$Email', '$password')";
				
		if ($conn->query($Signup_query) === TRUE) {
			echo "Good";
		}else{
			echo "Error";
		}
	}
?> 