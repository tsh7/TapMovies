<?php
	session_start();
	include 'db.php';
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	

		$C_id = $_POST['filter_course'];
		if($C_id =='onload'){
			$sql_reviews = "SELECT C_id, Professor, Difficulty, Grade, Textbook, Attendance, R_course, R_professor, Resource, Review_Time FROM Reviews 
				WHERE S_name='New Jersey Institute of Technology'";
		}
		if($C_id ==''){
			$sql_reviews = "SELECT C_id, Professor, Difficulty, Grade, Textbook, Attendance, R_course, R_professor, Resource, Review_Time FROM Reviews 
				WHERE S_name='New Jersey Institute of Technology'";
		}	
		if($C_id != 'onload'){
			$sql_reviews = "SELECT C_id, Professor, Difficulty, Grade, Textbook, Attendance, R_course, R_professor, Resource, Review_Time FROM Reviews 
				WHERE S_name='New Jersey Institute of Technology' and C_id = '$C_id'";
		}
			$result = mysqli_query($conn, $sql_reviews);
			$num_rows=mysqli_num_rows($result);
			$num_cols=mysqli_num_fields($result);
			$data_rows=mysqli_fetch_assoc($result);
			echo '<div id="course-reviews" style="display:block;">';
			        echo '<table class="course-review-table" border="0">';
          echo '<tbody>';
            echo '<tr id="" class="">';
              echo '<th id="reviews-table-header"><h2>New Jersey Institute of Technology - Course Reviews</h2></th>';
            echo '</tr>';
			
			do  
			{
				
				echo '<tr id="enter-unique-id-here" class="row-size">';
				echo '<!--LEFT--SIDE--REVIEW--CONTECT-->';
				echo '<td class="short-review">';
                
				echo '<span class="professor"> Course Professor: '.$data_rows['Professor'];
					echo '<span class="response"></span>';
				echo '</span>';
				
				echo '<span class="difficulty"> Level of Difficulty: '.$data_rows['Difficulty'];
					echo '<span class="response"></span>';
				echo '</span>';
				
				echo '<span class="grade"> Grade Received: '.$data_rows['Grade'];
					echo '<span class="response"></span>';
				echo '</span>';
				
				echo '<span class="textbook"> Textbook Required: '.$data_rows['Textbook'];
					echo '<span class="response"></span>';
				echo '</span>';
				
				echo '<span class="attendance"> Attendance Required: '.$data_rows['Attendance'];
					echo '<span class="response"></span>';
				echo '</span>';
				
				echo '<span class="resources"> <p id="p01">Course Resources:<p>';
					echo '<span class="response">';
						echo '<p class="resourceContainer">'.$data_rows['Resource'].'</p>';
					echo '</span>';
				echo '</span>';
			  echo '</td>';
			  
			echo '<!--RIGHT--SIDE--REVIEW--CONTECT--> ';
			  echo '<td class="long-review">';
					echo '<div class="long-rev-top">';
						echo '<span class="courseID"> Course ID: '.$data_rows['C_id'];
							echo '<span class="response"></span>';
						echo '</span>';
						
						echo '<span class="postDate"> Date of Review: '.date('m/d/Y', strtotime($data_rows['Review_Time']) );
							echo '<span class=""></span>';
						echo '</span>';
					echo '</div>';
					
					echo '<div class="long-rev-content">';
						echo '<span class="courseReview">';
						echo 'Course Review';
							echo '<p class="course-review-cointainer">'.$data_rows['R_course'].'</p>';
						echo '</span>';
						echo '<span class="professorReview">';
						echo 'Professor Review';
							echo '<p class="professor-review-cointainer">'.$data_rows['R_professor'].'</p>';
						echo '</span>';
					echo '</div>';
			  echo '</td>';
            echo '</tr>';
			}while ($data_rows=mysqli_fetch_assoc($result));
	          echo '</tbody>';
         echo '</table>'; 
		echo '</div>';
		echo '</div>';
?>