  <?php
//hash password
	$Email=$_SESSION['Email'];
	
    $php_data= array("Function"=>"S_W_M_id","Email" => $Email, "W_M_id" => $W_M_id);

    $data = json_encode($php_data);
    require_once __DIR__ . '/vendor/autoload.php';
    use PhpAmqpLib\Connection\AMQPConnection;
    use PhpAmqpLib\Message\AMQPMessage;

    $connection = new AMQPConnection('192.168.1.101', 5672, 'admin', 'guest');
    $channel = $connection->channel();

    $channel->queue_declare('WWW_T_DB', false, false, false, false);

    $msg = new AMQPMessage($data, array('delivery_mode' => 2));
    $channel->basic_publish($msg, '', 'WWW_T_DB');
    $channel->close();
    $connection->close();
    include 'Store_M_id_DB_T_WWW.php';
   ?>
