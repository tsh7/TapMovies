<?php
echo "<td>";
$M_id=$R_Data['results'][$x]['id'];
//echo "<div>".$M_id."</div>";
echo "<div class='resourceContainer'>";
echo "<a href='Movie_Detail.php?M_id=".$M_id."'><img src='".$img_dir.$img."' style='width:140px;height:140px;'></a>";
//echo '<a href="Movie_Detail.php?M_id="'.$M_id.'"><img src="'.$img_dir.$img.'" style="width:140px;height:140px;"></a>';
echo "<br />";
print_r($R_Data['results'][$x]['title']);
echo '<pre>                              </pre>';
echo "</div>";
echo "</td>";
?>
