<?php
$selectState = $_POST['selectState'];
switch ($selectState) {
    case "NJ":
        $msg='<option value="New Jersey Institute of Technology"></option>
		<option value="Rutgers University"></option>
		<option value="Princeton University"></option>';
		echo $msg;
        break;
    case "NY":
        $msg='<option value="Columbia University"></option>
		<option value="Cornell University"></option>
		<option value="New York University"></option>';
		echo $msg;
        break;
    default:
        $msg='<h1>error<h1>';
		echo $msg;
}
?>