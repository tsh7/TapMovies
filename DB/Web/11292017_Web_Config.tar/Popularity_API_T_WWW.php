<?php

require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPConnection;

$connection = new AMQPConnection('192.168.1.101', 5672, 'admin', 'guest');
$channel = $connection->channel();

$channel->queue_declare('API_T_WWW', false, false, false, false);

//echo ' * Waiting for messages. To exit press CTRL+C', "\n";

$callback = function($msg){

//echo " * Message received", "\n";

$R_Data = json_decode($msg->body, true);

$img_dir="https://image.tmdb.org/t/p/w500";
$M_size = sizeof($R_Data['results']);
$x=0;
echo "<table>";
while($x<$M_size){
$img=$R_Data['results'][$x]['poster_path'];
echo "<tr>";
echo "<td>";
echo '<img src="'.$img_dir.$img.'" style="width:128px;height:128px;">';
echo '<pre>                              </pre>';
echo "<br />";
print_r($R_Data['results'][$x]['title']);
echo "</td>";
$x++;
if($x == $M_size){
	echo "</tr>";
	break;
}
echo "<td>";
$img=$R_Data['results'][$x]['poster_path'];
echo '<img src="'.$img_dir.$img.'" style="width:128px;height:128px;">';
echo '<pre>                              </pre>';
echo "<br />";
print_r($R_Data['results'][$x]['title']);
echo "</td>";
$x++;
if($x == $M_size){
	echo "</tr>";
	break;
}
echo "<td>";
$img=$R_Data['results'][$x]['poster_path'];
echo '<img src="'.$img_dir.$img.'" style="width:128px;height:128px;">';
echo '<pre>                              </pre>';
echo "<br />";
print_r($R_Data['results'][$x]['title']);
echo "</td>";
echo "</tr>";
$x++;
}
echo "</table>";
};

$channel->basic_consume('API_T_WWW', '', false, true, false, false, $callback);
//while(count($channel->callbacks)){
$channel->wait();
//}
$channel->close();
$connection->close();
?>