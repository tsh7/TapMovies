<html>
	<head>
		<title>StudentCoLabs</title>
		<link rel="stylesheet" type="text/css" href="main.css">
	</head>
<?php
session_start();
include 'db.php';
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
	<body>

		<div id="wrapper">
			
			<div id="header">
				<img src="colab.PNG" alt="SCL Logo" class="float_left">
				<h1 class="float_left">StudentCoLab</h1>
<?php
if(!isset($_SESSION['U_id'])){
	if(!isset($_POST['Login'])){
		readfile('Login.html');
		readfile('account.html');
		readfile('Modal.js');
	}elseif(($_POST[Email]=="") or ($_POST[Password]=="")){
		header("Location: index.php");
	}else{
		$Email = $_POST['Email'];
		$Password = $_POST['Password'];
		$query = "select Email, U_id  from User where Email='$Email' and Password='$Password'";
        $strSQL = mysqli_query($conn,$query);
        $Results = mysqli_num_rows($strSQL);
		$row=mysqli_fetch_assoc($Results);
        if($Results == 1){
            $_SESSION['U_id']=$row["U_id"];
			header("Location: index.php");
        }else{
			header("Location: index.php");
		}
	}
}elseif(isset($_SESSION['U_id'])){
	if(!isset($_POST['Logout'])){
		include "Logout.html";
	}elseif(isset($_POST['Logout'])){
		session_unset(); 
		session_destroy(); 
		header("Location: index.php");
	}
}
?>



			</div>
			<div id="middle">
				<div id="introtxt">
					<h1>Welcome to StudentCoLab</h1>
					<h4 id="introtext"><i>A place where students collaborate by sharing information about college courses and other academic resources. 
					Our website provides a great source of information for college students, as well as prospective students, who need in-depth
					information about college courses they plan on taking. Our reviews are provided by students. We encourage all students to 
					participate by contributing information to our website as it helps make our community stronger</i><h4>
				</div>
				<div id="search_school_form" >
				
					<form id="search_school">
						<strong>Select State:</strong>						
						<input list="StateBrowsers" name="StateBrowsers" id="selectState">
						<datalist id="StateBrowsers">
							<option>         </option>
							<option value="NJ" >New Jersey</option>
							<option value="NY">New York</option>
						</datalist>
						
						<strong>Enter School:</strong>
						<input list="SchoolBrowsers" name="SchoolBrowsers" id="schools">
						<datalist id="SchoolBrowsers">
							<div id="displaySchools"></div>
						</datalist>
						<input id="searchBTN" type="button" value="Search" onclick="goSchool()"><br>
					</form>
					
				</div>
			</div>
			<div id="footer">
				<div class="footer_box">
					<p><b><font size="4">Support</font></b></p>
					<p><a href="https://www.google.com">Contact</a></p>
					<p><a href="https://www.google.com">FAQs</a></p>
					<p><a href="https://www.google.com">Member Support</a><p>
				</div>
				<div class="footer_box">
					<p><b><font size="4">About</font></b></p>
					<p><a href="https://www.google.com">Our Story</a></p>
					<p><a href="https://www.google.com">Terms & Conditions</a></p>
					<p><a href="https://www.google.com">Privacy Policy</a><p>
				</div>
				<div class="footer_box">
					<div id="social">
						<p><b><font size="4">Follow Us</font></b></p>
						<ul style="list-style-type:none">
							<li><a href="https://www.google.com"><img src="u32.png" style="width:25px;height:25px;"></a></li>
							<li><a href="https://www.google.com"><img src="u33.png" style="width:25px;height:25px;"></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
<script src="goSchool.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>

$(document).ready(function(){
	$('#selectState').blur(function(){
		var selectState = $('#selectState').val();
		
		if(selectState != '')
		{
			$.ajax({
				url:"selectSchools.php",
				method:"POST",
				data:{selectState:selectState},
				success:function(data)
				{
					$("#displaySchools").html(data);
				}
			});
		}
	});
});

</script>
	</body>
</html>