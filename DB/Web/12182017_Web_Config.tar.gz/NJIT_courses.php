<!DOCTYPE html>
<html>
	<head>
		<title>NJIT courses</title>
		<link rel="stylesheet" type="text/css" href="main.css">
		<?php
			session_start();
			include 'db.php';
			if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
			}
		?>
	</head>
	<body>
		<div id="wrapper">
<!-------------------------------------HEADER--------------------------------------------------------------------------------------------------->			
      
      <div id="courses_header">
				<a href="index.php"><img src="colab.png" alt="SCL Logo" ></a>
				<h1>New Jersey Institute of Technology</h1>
			</div>
      
<!-----------------------------SCHOOL--INFORMATION--SECTION--------------------------------------------------------------------------------------------------->
			
      <div id="school-info-wrapper" class="school_info">
				<div id="info1" class="float_left">
					<ul>
						<p style="text-align:center;font-size:14px;"><b>General Info</b></p>
						<li><b>Mascot: </b>The Highlander</li><br/>
						<li><b>Website: </b>http://www.njit.edu</li><br/>
						<li><b>Campus Directory: </b>http://directory.njit.edu</li><br/>
						<li><b>Address: </b>323 Dr Martin Luther King Jr Blvd, Newark, NJ 07102</li>
					</ul>
				</div>
				<div id="info2" class="float_left">
					<p style="text-align:center;font-size:14px;"><b>About NJIT</b></p>
					<p>New Jersey Institute of Technology is a public institution that was founded in 1881. 
					New Jersey Institute of Technology's ranking in the 2018 edition of Best Colleges is National Universities, 
					140</p>
					<button id="forum-button"><b>STUDENT FORUM<b></button>
				</div>
				
				<div id="school_map" class="float_left">
					<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d12091.580254230155!2d-74.1793409!3d40.7423345!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0                           %3A0xb97c287a2ef95f43!2sNew+Jersey+Institute+of+Technology!5e0!3m2!1sen!2sus!4v1509946032270" 
					width="329" height="200" frameborder="0" style="border:0" allowfullscreen></iframe>
				</div>
			</div>
			
<!-----------------------------COURSE--SEARCH--FILTER--SECTION--------------------------------------------------------------------------------------------------->        
			<div id="search-courses-wrapper" >
				<div id="sort-courses">
				<form id="sort-courses-form">
  					<label>Search by Course ID</label><br><br>
  					<input type="search" id="filter_course" name="course-search" placeholder="E.g. CS101" />
  					<input type="button" id="Search_courses" value="Search"/><br>
  				</form>
        </div>
				<button id="add_new_course_btn" onclick="window.location='course_review_forum.php'"><b>Post Course Review<b></button>
			</div>
			
<!-----------------------------COURSE--REVIEWS--TABLE--SECTION-------------------------------------------------------------------------------------------------->  
		
		
            <div id="display_courses"></div>
		
<!-----------------------------COURSE--REVIEWS--TABLE--SECTION--------------------------------------------------------------------------------------------------> 

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>

$(document).ready(function(){
	
		var filter_course = 'onload';
		
			$.ajax({
				url:"display_courses.php",
				method:"POST",
				data:{filter_course:filter_course},
				success:function(data)
				{
					$("#display_courses").html(data);
				}
			});
	
	
	$('#Search_courses').click(function(){
		
		var filter_course = $('#filter_course').val();
		if(filter_course == ''){
			var filter_course = 'onload';
			$.ajax({
				url:"display_courses.php",
				method:"POST",
				data:{filter_course:filter_course},
				success:function(data)
				{
					$("#display_courses").html(data);
				}
			});
		}else{
			$.ajax({
				url:"display_courses.php",
				method:"POST",
				data:{filter_course:filter_course},
				success:function(data)
				{
					if(data != 'Others'){
						$("#display_courses").html(data);
					}else{
						alert("Only student can write a course review");
					}
				}
			});
		}
	});
});

</script>
	</body>
</html>