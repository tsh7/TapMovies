<?php
include("db.php");
if($conn->connect_error){
	die("Connection failed" . $conn->connect_error);
}

mysql_select_db("mk599");

//this function will run each array within each POST array including
//multi-dimensional arrays
function ExtendedAddslash(&$params){
	foreach ($params as &$var){
		//check of $var is an array. If yes, it will start another
		//ExtendedAddslash() function to loop to each key inside
		is_array($var) ? ExtendedAddslash($var) :
		$var=addslashes($var);
	}
}
ExtendedAddslash($_POST);

$Email=$_POST["email"];
$C_id=$_POST["courseid"];
$Professor=$_POST["prof"];
$Difficulty=$_POST["diff"];
$Grade=$_POST["grade"];
$Textbook=$_POST["cbox1"];
$Attendance=$_POST["cbox2"];
$R_course=htmlspecialchars($_POST["course_review_box"]);
$R_professor=htmlspecialchars($_POST["professor_review_box"]);
$Resource=htmlspecialchars($_POST["resource_box"]);

$query="SELECT * FROM Review WHERE Email=$Email and C_id=$C_id";
$sqlsearch=mysql_query($query);
$resultcount=mysql_num_rows($sqlsearch);

if($resultcount > 0){
	mysql_query("UPDATE Review SET
			Professor=$Professor,
			Difficulty=$Difficulty,
			Grade=$Grade,
			Textbook=$Textbook,
			Attendance=$Attendance,
			R_course=$R_course,
			R_professor=$R_professor,
			Resource=$Resource
			WHERE Email=$Email and C_id=$C_id")
	or die(mysql_error());
}
else{
	mysql_query("INSERT INTO `Review`(`Email`, `C_id`,
		    `Professor`, `Difficulty`, `Grade`, `Textbook`, `Attendance`		    
		    ,`R_course`, `R_professor`, `Resource`)
		    VALUES('$Email','$C_id','$Professor',
		    '$Difficulty','$Grade','$Textbook','$Attendance','$R_course'
		    ,'$R_professor','$Resource')")
	or die(mysql_error());
}
echo '<a href="NJIT_courses.html"> Thank you for your submission click me to go back </a>';
?>

			
