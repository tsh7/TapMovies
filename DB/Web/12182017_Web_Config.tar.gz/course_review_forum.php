<?php
session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>NJIT courses</title>
		<link rel="stylesheet" type="text/css" href="main.css">
	</head>
	<body>
		<div id="wrapper">
			<div id="courses_header">
				<a href="index.php"><img src="colab.png" alt="SCL Logo"></a>
				<h1>Course Review</h1>
			</div>
			
			<form id="review_content" class="review-content" action="NJIT_course.php" method="post">
					<div class="container">
					  
					  <h1>NJIT Course Review</h1>					  	  
					  <label for="courseid"><b>Enter Course ID</b></label><br>
					  <input type="text"  id = "C_id" placeholder="E.g. CS101" name="courseid" required><br><br>

					  <label for="prof"><b>Name of Professor</b></label><br>
					  <input type="text" id = "prof" name="prof" required><br><br>

					  <label for="diff"><b>Level of Difficulty:</b></label><br>
					  <input type="radio" id = "diff" name="diff" value="High">High
					  <input type="radio" id = "diff" name="diff" value="Medium">Medium
					  <input type="radio" id = "diff" name="diff" value="Low">Low<br><br>
					  
					  <label for="grade"><b>Grade Received:</b></label><br>
					  <input type="radio" id = "grade" name="grade" value="A">A
					  <input type="radio" id = "grade" name="grade" value="B">B
					  <input type="radio" id = "grade" name="grade" value="C">C
					  <input type="radio" id = "grade" name="grade" value="D">D
					  <input type="radio" id = "grade" name="grade" value="F">F<br><br>
					  
					  <label for="Textbook"><b>Textbook Required?</b></label><br>
					  <input type="radio" id = "Textbook" name="Textbook" value="yes">Yes
					  <input type="radio" id = "Textbook" name="Textbook" value="no">No<br><br>
					  
					  <label for="Attendance"><b>Attendance Required?</b></label><br>
					  <input type="radio" id = "Attendance" name="Attendance" value="yes">Yes
					  <input type="radio" id = "Attendance" name="Attendance" value="no">No<br><br>
					  
					  <label for="R_course"><b>Course Review</b></label><br>
					  <textarea rows="4" cols="45" id = "R_course" name="R_course" required></textarea><br><br>
					  
					  <label for="R_professor"><b>Professor review</b></label><br>
					  <textarea rows="4" cols="45" id = "R_professor" name="R_professor" required></textarea><br><br>
					  
					  <label for="resource_box"><b>Course Resources(Resources that helped you in the course)</b></label><br>
					  <textarea rows="4" cols="45" id = "resource_box" name="resource_box"></textarea><br><br>

					  <div id="modle_buttons" class="clearfix">
						<button type="button" onclick="window.location='NJIT_courses.php'" class="cancelbtn">Cancel</button>
						<button type="button" id = "Review_submit" class="signupbtn">Submit</button>
					  </div>
					</div>
		</form>
		</div>	

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>

<script>

$(document).ready(function(){
	$('#Review_submit').click(function(){
		
		var U_id = '<?php echo $_SESSION["U_id"]; ?>';
		if(U_id == ''){
			alert("Login is required to post a review");
		}else{
			var C_id = $('#C_id').val();
			var prof = $('#prof').val();
			var diff = $("input[name='diff']:checked").val();
			var grade = $("input[name='grade']:checked").val();
			var Textbook = $("input[name='Textbook']:checked").val();
			var Attendance = $("input[name='Attendance']:checked").val();
			var R_course = $('#R_course').val();
			var R_professor = $('#R_professor').val();
			var resource_box = $('#resource_box').val();	

			if(U_id !='' && C_id != '' && prof != '' && diff != '' && grade != '' && 
				Textbook != '' && Attendance != '' && R_course != '' && R_professor != '' &&
				resource_box != '')
			{
				$.ajax({
					url:"submit_Review.php",
					method:"POST",
					data:{U_id:U_id, C_id:C_id, prof:prof,diff:diff, grade:grade, Textbook:Textbook,Attendance:Attendance,
						R_course:R_course, R_professor:R_professor, resource_box:resource_box},
					success:function(data)
					{
						if($.trim(data) == "Good")
						{
							window.location.replace("NJIT_courses.php");
						}
						else if($.trim(data) == "Error")
						{
							alert("Unknown error occured. Please retry");
						}
						else if($.trim(data) == "Others")
						{
							alert("Only student users can write a review");
						}
					}
				});
			}
			else
			{
				alert("All Fields are required");
			}
		}
	});	
});
</script>
	</body>
</html>