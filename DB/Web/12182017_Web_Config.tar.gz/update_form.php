<?php
	include 'db.php';
	
	$U_level = $_POST['U_level'];
	
	if($U_level == "Student"){
		
		$U_id = $_POST['U_id'];
		$State = $_POST['State'];
		$S_name = $_POST['School'];
		$Email = $_POST['Email'];
		$Password = $_POST['Password'];

		$Update_query = "UPDATE User SET U_level='$U_level', State='$State', S_name='$S_name', Email='$Email', Password='$Password' WHERE U_id='$U_id' and Password = '$Password'";
		
		
		if ($conn->query($Update_query) === TRUE) {
			echo mysqli_affected_rows($conn);
		}else{
			echo "error";
		}
	}elseif($U_level == "Others"){
		$U_id = $_POST['U_id'];
		$Email = $_POST['Email'];
		$Password = $_POST['Password'];

		$Update_query = "UPDATE User SET U_level='$U_level', Email='$Email', Password='$Password' WHERE U_id='$U_id' and Password = '$Password'";
		
		
		if ($conn->query($Update_query) === TRUE) {
			echo mysqli_affected_rows($conn);
		}else{
			echo "error";
		}
	}
?> 