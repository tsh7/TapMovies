<form id="logoutForm" method="post" class="float_right">
<br />
<a><?php echo $_SESSION['Email']; ?></a>
<br />
<input type="submit" name="Logout" value="Logout"><br />
</form>