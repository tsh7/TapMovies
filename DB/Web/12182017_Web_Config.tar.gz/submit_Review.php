<?php
include("db.php");
if($conn->connect_error){
	die("Connection failed" . $conn->connect_error);
}
$S_name = "New Jersey Institute of Technology";
$U_id = $_POST['U_id'];
$C_id = $_POST['C_id'];
$Professor = $_POST['prof'];
$Difficulty = $_POST['diff'];
$Grade = $_POST['grade'];
$Textbook = $_POST['Textbook'];
$Attendance = $_POST['Attendance'];
$R_course = htmlspecialchars($_POST['R_course']);
$R_professor = htmlspecialchars($_POST['R_professor']);
$Resource = htmlspecialchars($_POST['resource_box']);


$sql_U_level = "SELECT U_level FROM User WHERE U_id ='$U_id'";
$U_Level_result = mysqli_query($conn, $sql_U_level);
$U_level_value=mysqli_fetch_assoc($U_Level_result);
$U_level = $U_level_value['U_level'];
if($U_level == 'Student'){
	$sql_input_review = "INSERT INTO Reviews (S_name, U_id, C_id, Professor, Difficulty, Grade, Textbook, Attendance, R_course, R_professor, Resource, Review_Time)
		VALUES ('$S_name', '$U_id', '$C_id', '$Professor', '$Difficulty', '$Grade', '$Textbook', '$Attendance', '$R_course', '$R_professor', '$Resource',NOW())";

	if($conn->query($sql_input_review) === TRUE){
		echo "Good";
	}else{
		echo "Error";
	}
}else{
	echo("Others");
}
?>

			
