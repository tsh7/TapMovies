
			function NJSchools(){
      // NJ College list start
				var schools = new Array();
				schools[0]='New Jersey Institute of Technology';
				schools[1]='Rutgers University';
				schools[2]='Princeton University';

				var options_schools = '';

				for(var i = 0; i < schools.length; i++)
				options_schools += '<option value="'+schools[i]+'" />';

				document.getElementById('schools').innerHTML = options_schools;
				// NJ College list ends
			}
      
      
			function NYSchools(){
			// NY College list start
			var schools = new Array();
			schools[0]='New York University';
			schools[1]='Columbia University';
			schools[2]='Cornell University';
					
			var options_schools = '';

			for(var i = 0; i < schools.length; i++)
			options_schools += '<option value="'+schools[i]+'" />';

			document.getElementById('schools').innerHTML = options_schools;
			// NY College list ends			
			}