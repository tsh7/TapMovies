function goSchool(){
	var school = document.getElementById('schools').value;
	switch (school) {
		case "New Jersey Institute of Technology":
			window.location.assign("NJIT_courses.php")
			break;
		case 'Rutgers University':
			window.location.assign('Rutgers_courses.html');
			break;
		case 'Princeton University':
			window.location.assign('Princeton_courses.html');
			break;
		case 'New York University':
			window.location.assign('New_York_courses.html');
			break;
		case 'Columbia University': 
			window.location.assign('Columbia_courses.html');
			break;
		case 'Cornell University':
			window.location.assign('Cornell_courses.html');
			break;
		default:
			window.location.assign("index.php")
	}
}