<?php
	$Search = array("Function"=>"Search_movie","M_name" => $M_name);

	$data = json_encode($Search);

	require_once __DIR__ . '/vendor/autoload.php';
	use PhpAmqpLib\Connection\AMQPConnection;
	use PhpAmqpLib\Message\AMQPMessage;

	$connection = new AMQPConnection('192.168.1.101', 5672, 'admin', 'guest');
	$channel = $connection->channel();

	$channel->queue_declare('WWW_T_API', false, false, false, false);

	$msg = new AMQPMessage($data, array('delivery_mode' => 2));
	$channel->basic_publish($msg, '', 'WWW_T_API');
	$channel->close();
	$connection->close();
	include 'Search_API_T_WWW.php';
?>
