#!/bin/bash

#check if first argument exist
if [ -z "$1" ]
then
	#echo if first argument empty	
	echo "No argument input"
else
	#zip html folder
	zip -r $1 /var/www/html/

	#make the zip file name as variable
	zipVar="$1.zip"

	#variable for the path to be sent
	pathVar="/home/webuser/vc/$zipVar"

	#scp send the zipped folder
	scp webuser@192.168.1.203:$pathVar ben@192.168.1.101:/home/ben/IT490/VersionControl/WebServerVersion

	#scp send changelog
	scp webuser@192.168.1.203:/var/www/html/README.markdown ben@192.168.1.101:/home/ben/IT490/ChangeLog/WebServerChangeLog
fi
