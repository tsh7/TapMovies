<?php
/* variables to declare rabbitmq IP, port, username, password, query name
 * change below to modify them
*/
$rmq_ip   = '192.168.1.101';
$rmq_port = '5672';
$rmq_user = 'admin';
$rmq_pass = 'guest';

