<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

function registerFunction($email, $password, $firstName, $lastName, $phone){
  
}

?>
