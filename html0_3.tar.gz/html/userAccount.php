<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

//start session
session_start();
//load and initialize user class
//include 'user.php';
//include websend.php;
//$user = new User();
require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

//change rabbitmq ip here
$rmq_ip   = '192.168.1.201';
$rmq_port = '5672';
$rmq_user = 'admin';
$rmq_pass = 'guest';
$rmq_que  = 'WWW_DB';

if (isset($_POST['signupSubmit'])) {

    //hash the password
    $Pword_text = $_POST['password'];
    $Hash_Pword = crypt($Pword_text, 'ABCDE12345');
    //put user data into array
    $U_inf= array("Function"=>"Register",
            "Fname" => $_POST['first_name'],
            "Lname"=>$_POST['last_name'],
            "Email"=>$_POST['email'],
            "Pword"=>$Hash_Pword,
            "Phone"=>$_POST['phone']);
    //encode the array data using json
    $dataA = json_encode($U_inf);
    //establish a new connection and channel
    $connection = new AMQPStreamConnection($rmq_ip, $rmq_port, $rmq_user, $rmq_pass);
    $channel = $connection->channel();
    //channel declaration
    $channel->queue_declare($rmq_que, false, false, false, false);
    //send encoded user array data with rabbitmq
    $msg = new AMQPMessage($dataA, array('delivery_mode' => 2));
    $channel->basic_publish($msg, '', $rmq_que);

    //close the channel and connection
    $channel->close();
    $connection->close();

    //store signup status into the session
    $_SESSION['sessData'] = $sessData;
    $redirectURL = ($sessData['status']['type'] == 'success')?'login.php':'registration.php';
    //redirect to the home/registration page
    header("Location:".$redirectURL);
} elseif (isset($_POST['loginSubmit'])) {
    //hash the password
    $Pword_text = $_POST['password'];
    $Hash_Pword = crypt($Pword_text, 'ABCDE12345');
    //put user data into array
    $U_infL= array("Function"=>"Login",
    "Email"=>$_POST['email'],
    "Pword"=>$Hash_Pword);
//encode the array data using json
    $dataL = json_encode($u_infL);
    //establish a new connection and channel
    $connection = new AMQPStreamConnection($rmq_ip, $rmq_port, $rmq_user, $rmq_pass);
    $channel = $connection->channel();
    //channel declaration
    $channel->queue_declare($rmq_que, false, false, false, false);
    //send encoded user array data with rabbitmq
    $msg = new AMQPMessage($dataL, array('delivery_mode' => 2));
    $channel->basic_publish($msg, '', $rmq_que);
    include 'receiver.php';
    //close the channel and connection
    $channel->close();
    $connection->close();

    //store login status into the session
    $_SESSION['sessData'] = $sessData;
    //redirect to the home page
    header("Location:login.php");
} elseif (!empty($_REQUEST['logoutSubmit'])) {
    //remove session data
    unset($_SESSION['sessData']);
    session_destroy();
    //store logout status into the ession
    $sessData['status']['type'] = 'success';
    $sessData['status']['msg'] = 'You have logout successfully from your account.';
    $_SESSION['sessData'] = $sessData;
    //redirect to the home page
    header("Location:login.php");
} else {
    //redirect to the home page
    header("Location:login.php");
}
