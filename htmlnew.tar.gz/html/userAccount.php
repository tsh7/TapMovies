<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

//start session
session_start();
require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

//rabbitmq info, change variables in RabbitMQinfo.php
include 'RabbitMQinfo.php';
//rabbitmq queue name
$rmq_que  = 'WWW_T_DB';
//rabbitmq receiver file location
$rmq_receiver = 'receiver.php';

if (isset($_POST['signupSubmit'])) {

    //hash the password
    $Pword_text = $_POST['password'];
    $Hash_Pword = crypt($Pword_text, 'ABCDE12345');
    //put user data into array
    $U_inf= array("Function"=>"Register",
            "Fname" => $_POST['first_name'],
            "Lname"=>$_POST['last_name'],
            "Username"=>$_POST['username'],
            "Email"=>$_POST['email'],
            "Pword"=>$Hash_Pword);
    //encode the array data using json
    $dataA = json_encode($U_inf);
    //establish a new connection and channel
    $connection = new AMQPStreamConnection($rmq_ip, $rmq_port, $rmq_user, $rmq_pass);
    $channel = $connection->channel();
    //channel declaration
    $channel->queue_declare($rmq_que, false, false, false, false);
    //send encoded user array data with rabbitmq
    $msg = new AMQPMessage($dataA, array('delivery_mode' => 2));
    $channel->basic_publish($msg, '', $rmq_que);
    //close the channel and connection
    $channel->close();
    $connection->close();
    //rabbitmq receiver feedback
    include $rmq_receiver;
} elseif (isset($_POST['loginSubmit'])) {
    echo "login php running";
    //hash the password
    $loginPass = $_POST['password'];
    $hashLogin = crypt($loginPass, 'ABCDE12345');
    //put user data into array
    $infoL= array("Function"=>"Login",
            "Username"=>$_POST['username'],
            "Pword"=>$hashLogin);
    //encode the array data using json
    $dataL = json_encode($infoL);
    //establish a new connection and channel
    $connection = new AMQPStreamConnection($rmq_ip, $rmq_port, $rmq_user, $rmq_pass);
    $channel = $connection->channel();
    //channel declaration
    $channel->queue_declare($rmq_que, false, false, false, false);
    //send encoded user array data with rabbitmq
    $msgL = new AMQPMessage($dataL, array('delivery_mode' => 2));
    $channel->basic_publish($msgL, '', $rmq_que);
    //close the channel and connection
    $channel->close();
    $connection->close();
    //rabbitmq receiver feedback
    include $rmq_receiver;
} elseif (!empty($_REQUEST['logoutSubmit'])) {
    //redirect to destroy session
    header("Location:destroy.php");
} else {
    //redirect to the home page
    header("Location:destroy.php");
}
