<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

//session_start();

//rabbitmq info, change variables in RabbitMQinfo.php
include 'RabbitMQinfo.php';
$rmq_que  = 'API_T_WWW';

    require_once __DIR__ . '/vendor/autoload.php';
    use PhpAmqpLib\Connection\AMQPStreamConnection;

    $connection = new AMQPStreamConnection($rmq_ip, $rmq_port, $rmq_user, $rmq_pass);
    $channel = $connection->channel();

    $channel->queue_declare($rmq_que, false, false, false, false);

    $callback = function ($msg) {
        $R_Data = json_decode($msg->body);
        echo "<pre>";
        foreach ($R_Data->results as $mydata) {
            //echo $mydata->title . "<br>";
            $movieTitle = $mydata->title;
            $movieID = $mydata->id;
            echo '  <div class="panel panel-default">
                <div class="panel-body">
                    <b> <a href="innerLI.php?varname='.$movieTitle.'&movid='.$movieID.'">'.$movieTitle.'</a></b>
                    <li>
                    <img src="https://image.tmdb.org/t/p/w500/'. $mydata->poster_path .'"/></li>
                </div>
            </div>';
        }
        echo "</pre>";
    };

    $channel->basic_consume($rmq_que, '', false, true, false, false, $callback);
    //while(count($channel->callbacks)){
    $channel->wait();
    //}
    $channel->close();
    $connection->close();
