<?php
//Error report
error_reporting(E_ALL);
ini_set('display_errors', 1);
//start session
session_start();
//store username from session
$userSession = $_SESSION['username'];
//load AMQP library for RabbitMQ usage
require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;

//rabbitmq info, change variables in RabbitMQinfo.php
include 'RabbitMQinfo.php';
$rmq_que = 'WWW_T_DB';
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>My Account</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/modern-business.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->

  <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="indexLI.php">Tap Movies</a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="indexLI.php">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="topRatedLI.php">Top Rated</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="profile.php">My Account</a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="destroy.php">Log Out</a>
          </li>

        </ul>
      </div>
    </div>
  </nav>

  <!-- Page Content -->
  <div class="container">

    <h1 class="my-4"><?php
      $movieTitle = $_GET['varname'];
      echo $movieTitle;
    ?></h1>
    <h4>
      <?php
        $movieID = $_GET['movid'];
        echo "movieID is ". $movieID;
      ?>
      <br>
      <form id="ff" action="profile.php" onsubmit="sendData();">
        <input type="radio" name="wradio" id="watched"> Watched<br>
        <input type="radio" name="wradio" id="tobewatched"> To be Watched<br>
        <input type="submit" name="mysubmit" value="Submit"><br>
        </form>
      <script type="text/javascript">
          var button1 = document.getElementById("watched");
          var button2 = document.getElementById("tobewatched");
          function sendData(){
          if (button1.checked = true){
            <?php

            $sendRMQ = array("Function"=> "watchdata",
                          "task" => "watched",
                          "username" => $userSession,
                          "M_id" => $movieID);
            $data = json_encode($sendRMQ);

            $connection = new AMQPStreamConnection($rmq_ip, $rmq_port, $rmq_user, $rmq_pass);
            $channel = $connection->channel();

            $channel->queue_declare($rmq_que, false, false, false, false);

            $msg = new AMQPMessage($data, array('delivery_mode' => 2));
            $channel->basic_publish($msg, '', $rmq_que);
            $channel->close();
            $connection->close();
            ?>
            alert("Watched List added");
          }else if (button2.checked = true) {
            alert("radio2 selected");
          }
        }
      </script>
      <?php

      ?>
    </h4>

  </div>
  <!-- /.container -->

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; Tap Movies 2017</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/popper/popper.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

</body>

</html>
