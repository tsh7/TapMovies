<?php
//This php code is for unset session data then redirect to homepage
session_start();
unset($_SESSION['email']);
unset($_SESSION['username']);
session_destroy();

header("Location: index.html");
exit;
?>
