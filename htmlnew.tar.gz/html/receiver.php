<?php
//Error report
error_reporting(E_ALL);
ini_set('display_errors', 1);
//load AMQP library for RabbitMQ usage
require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;

//rabbitmq info, change variables in RabbitMQinfo.php
include 'RabbitMQinfo.php';
//rabbitmq queue name
$rmq_que  = 'DB_T_WWW';

    $connection = new AMQPStreamConnection($rmq_ip, $rmq_port, $rmq_user, $rmq_pass);
    $channel = $connection->channel();

    $channel->queue_declare($rmq_que, false, false, false, false);

    $callback = function ($msg) {
        $dataX = json_decode($msg->body, true);//decode json as array(true);
        echo "<pre>";
        //do action based on data received from array key 'Function' value
        $funct = $dataX["Function"];
        echo $funct;
        echo "\n";
        //if function key value is login, do
        if ($funct=="Login") {
            echo "receiving login feedback";
            //if L_result key value is fail, redirect to delete session and exit
            if ($dataX["L_result"] == "Fail") {
                ?>
                <script type="text/javascript">
                alert("Incorrect username/password");
                window.location.href = "login.html";
                </script>
                <?php
            }
            //if L_result key value is success,
            elseif ($dataX["L_result"] == "Success") {
                //store login session
                $_SESSION['username'] = $_POST['username'];
                //redirect successful login
                header("Location:loggedin.php");
            }
        }
        //if Function key value is register
        elseif ($funct=="Register") {
            echo "Register feedback";
            //successful registration
            if ($dataX["R_result"] == "Success") {
                ?>
                <script type="text/javascript">
                alert("Registration Success!");
                window.location.href = "login.html";
                </script>
                <?php
            }
            //if registration fail
            else {
              ?>
              <script type="text/javascript">
              alert("Registration Fail!");
              window.location.href = "register.html";
              </script>
              <?php
            }
        }
        echo "</pre>";
    };

    $channel->basic_consume($rmq_que, '', false, true, false, false, $callback);
    //while(count($channel->callbacks)){
    $channel->wait();
    //}
    $channel->close();
    $connection->close();
