<?php
//Error report
error_reporting(E_ALL);
ini_set('display_errors', 1);
//load AMQP library for RabbitMQ usage
require_once __DIR__ . '/vendor/autoload.php';
use PhpAmqpLib\Connection\AMQPStreamConnection;
use PhpAmqpLib\Message\AMQPMessage;
//rabbitmq info, change variables in RabbitMQinfo.php
include 'RabbitMQinfo.php';
$rmq_que  = 'WWW_T_API';
?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Search Result</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/modern-business.css" rel="stylesheet">

  </head>

  <body>

    <!-- Navigation -->

    <nav class="navbar fixed-top navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="index.html">Tap Movies</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.html">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="topRated.php">Top Rated</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="atoz.html">A-Z List</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                My Account
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
                <a class="dropdown-item" href="login.php">Login</a>
                <a class="dropdown-item" href="registration.php">Register</a>
              </div>
            </li>

          </ul>
        </div>
      </div>
    </nav>
<h3>
  Top Rated Movies
</h3>


    <h5>
      <?php
    //RABBITMQ send
    //encode information in json
    $sendRMQ = array("Function"=> "TopRate");
    $data = json_encode($sendRMQ);

    $connection = new AMQPStreamConnection($rmq_ip, $rmq_port, $rmq_user, $rmq_pass);
    $channel = $connection->channel();

    $channel->queue_declare($rmq_que, false, false, false, false);

    $msg = new AMQPMessage($data, array('delivery_mode' => 2));
    $channel->basic_publish($msg, '', $rmq_que);
    $channel->close();
    $connection->close();
    include 'topRatedReceiver.php';
    ?>
    </h5>

    <!-- Page Content -->
	<div class="container" >

      <!-- Call to Action Section -->

      <div class="row mb-4">
        <div class="col-md-8">
          <p>  Having Any Issue?</p>
        </div>
        <div class="col-md-4">
          <a class="btn btn-lg btn-secondary btn-block" href="#">Contact Us</a>
        </div>
      </div>
	</div>
    </div>
    <!-- /.container -->

    <!-- Footer -->
    <footer class="py-5 bg-dark">
      <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; Tap Movies 2017</p>
      </div>
      <!-- /.container -->
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/popper/popper.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

  </body>

</html>
