<?php
//rabbitmq info, change variables in RabbitMQinfo.php
include 'RabbitMQinfo.php';
$rmq_que  = 'API_T_WWW';
    $r_data = json_encode($php_data);//convert $php_data array to json data
    require_once __DIR__ . '/vendor/autoload.php';//ribbitMQ library
    use PhpAmqpLib\Connection\AMQPStreamConnection;//ribbitMQ library
    use PhpAmqpLib\Message\AMQPMessage;//ribbitMQ library
    echo "sending result";
    $connection = new AMQPStreamConnection($rmq_ip, $rmq_port, $rmq_user, $rmq_pass);
    $channel = $connection->channel();//create channel
    $channel->queue_declare($rmq_que, false, false, false, false);//open channel
    $msg = new AMQPMessage($r_data, array('delivery_mode' => 2));//convert json data to rabbitMQ message
    $channel->basic_publish($msg, '', $rmq_que);//send message to Webserver
    echo "result sent";
    $channel->close();
    $connection->close();
//print_r($r_data);//test purpose to see if the result is good or not
